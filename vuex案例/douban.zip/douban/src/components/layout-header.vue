<template>
    <div class="my-header">
        <!-- 直接获取共享状态中的数据 -->
        <span>{{ $store.state.title }}</span>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
