import Vue from 'vue'
import App from './App.vue'
import vuex from 'vuex'  // 引入vuex
Vue.use(vuex) // Vue.use 调用了 vuex对象中的一个install方法
// 实例化一个vuex对象
// vuex.store是 vuex中 实例对象
const store = new vuex.Store({
  // 构造参数
  // 公共状态
  state: {
    count: 0, // count 此时已经是公共状态了
    name: '张三'
  },
  // 修改公共状态的方法 只能是同步代码
  mutations:{
    // add方法 是更改 state的方法
    // state是当前的state对象, payload是 传输的参数对象
    updateCount (state, payload) {
      // 直接对于state中的数据进行修改
       state.count += payload.step  // 每次加传过来的步长
    }
  },
  // 异步数据获取方式 想要更改state必须通过mutaitons
  actions:{
    // 获取数据的action 异步的 setTimeout /setInterval
    // store就是 当前store实例对象 store.state 获取  store.commit() 
    getCount (store, num) {
      setTimeout(function(){
          // 生成一个值 加到state中的count上
          // 所有state的修改只能通过mutations
          store.commit('updateCount', {
            step: num
          })
      }, 0)
    }
  }
})
Vue.config.productionTip = false

// 挂载到vue实例上
new Vue({
  render: h => h(App),
  store
}).$mount('#app')
