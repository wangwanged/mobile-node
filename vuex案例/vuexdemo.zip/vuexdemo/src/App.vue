<template>
  <div id="app">
    <!-- 如果在组件中 使用 state呢 -->
    <!-- 直接使用$store获取state数据 -->
   公共状态的数据: {{ $store.state.count }}
   <child />
   <ChangeCount />
  </div>
</template>

<script>
import child from './child'
import ChangeCount from './change-count'
export default {
  name: 'App',
  components: {
    child,
    ChangeCount
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
