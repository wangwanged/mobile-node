<template>
  <div>
      <!-- 直接用$store获取 -->
      <p> 我是child组件,我读取到了公共数据 {{ $store.state.count }}</p>
      <!-- 可以用计算属性 -->
      <!-- <p>{{ childCount }}</p> -->
      <!-- mapState中对象的用法 -->
      <p>mapState:{{ count }} {{  name }}</p>
     </div>
</template>

<script>
import { mapState } from 'vuex'
export default {
    // 第一种方式  mapState方法 返回一个对象
//   computed:mapState({
//     //   key:value
//     // key 是计算属性的key value有两种形式 字符串 /函数
//     count2: 'name'  // 表示计算属性中有一个count名 来源于 store中的state.count
//   })
// 第二种方式
//  computed: mapState(['count', 'name']) // 表示 在计算属性中定义了两个字段 count=> $store.state.count  name  => $store.state.name
// 第三种方式
   computed: {
      ...mapState(['count','name']),
   }
}
</script>

<style>

</style>