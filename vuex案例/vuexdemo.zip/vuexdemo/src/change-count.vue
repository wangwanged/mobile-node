<template>
  <div>
    <h2>修改公共状态的组件</h2>
    <!-- 放置当前的数字 -->
    <p>当前值: {{ count }}</p>
    <button @click="add">对当前的状态+</button>
    <button @click="cut">对当前的状态-</button>
    <button @click="mu">mapMutations方法</button>
    <button @click="aysncAdd">异步加</button>
    <button @click="getCount(500)">mapActions异步加</button>

  </div>
</template>

<script>
import { mapState, mapMutations, mapActions } from 'vuex'
export default {
  computed: {
      ...mapState(['count']) // 导入store中的count值
  },
//   mapMutations 可以帮助 我们把 store中mutations中的方法 映射到methods方法中
  methods: {
      add () {
        // 怎么修改公共状态的数据呢 ? 
        // this.$store.commit(mutations方法名, payload) // 第一个参数是方法名 第二个参数是载荷对象(可不传)
        // 载荷想传什么传什么
        this.$store.commit('updateCount', { step: 5 })
      },
      cut () {
          this.$store.commit('updateCount', {step: -5 })
      },
      mu () {
          this.updateCount({step: 10 }) // 相当于  this.$store.commit('updateCount', {step: 10 })
      },
    //   组件中怎么调用actions
      aysncAdd () {
       // store对象中 提供了 一个dispatch的方法  this.$store.dispatch(action名称, params(可不传))
        this.$store.dispatch("getCount", 100)
      },
      ...mapMutations([ 'updateCount' ]), // 相当于 在methods定义了一个方法 updateCount => 指向 store中的mutations中的updateCount方法
      ...mapActions(['getCount'])  // 此时 组件中就有了一个getCount方法 对应 store中action中的getCount
  }
}
</script>

<style>

</style>